<?php
/**
 * Template Name: Kalni Elementor
 */
the_post();
get_header();
echo "<div class='kalni-content-elementor'>";
the_content();
echo "</div>";
get_footer();