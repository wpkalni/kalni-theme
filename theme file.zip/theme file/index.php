<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Kalni
 */

get_header();
	$mainGridItem = '';
	$postGridItem = '';

	if (!wp_is_mobile()):
		$mainGridItem = 'grid-1-3 ';
		$postGridItem = 'grid-3 ';
	else:
		$mainGridItem = 'grid-1 ';
		$postGridItem = 'grid-1 ';
	endif;
	?>

		<main id="primary" class="site-main">
			<div class="container-85">
				<div class="kalni-blog grid <?php echo esc_attr($mainGridItem); ?>g-gap-50">
					<div class="blog-page-sidebar">
						<?php get_sidebar(); ?>
					</div>
					<div class="blog-page-content">
						<?php
						if (have_posts()):

							if (is_home() && !is_front_page()):
								?>
											<header>
												<h1 class="page-title screen-reader-text"><?php //single_post_title();  ?></h1>
											</header>
											<?php
							endif;
							?>
									<div class="blog-post-content grid <?php echo esc_attr($postGridItem); ?>g-gap-32">
										<?php
										/* Start the Loop */
										while (have_posts()):
											the_post();

											/*
											 * Include the Post-Type-specific template for the content.
											 * If you want to override this in a child theme, then include a file
											 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
											 */
											get_template_part('template-parts/content', get_post_type());

										endwhile;
										?>
									</div>
									<?php

									kalni_numeric_posts_nav();

						else:

							get_template_part('template-parts/content', 'none');

						endif;
						?>
					</div>
				</div>
			</div>
		</main><!-- #main -->
	<?php
get_footer();
